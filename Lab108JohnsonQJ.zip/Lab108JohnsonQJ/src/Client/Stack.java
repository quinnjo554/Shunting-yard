package Client;



/**
 *Stack Interface Class
 * Code Fragments 6.1
 * from
 * Data Structures & Algorithms, 6th edition
 * by Michael T. Goodrich, Roberto Tamassia & Michael H. Goldwasser
 * Wiley 2014
 * Transcribed by
 * @author Quinn Johnson
 * 
 * interface for stacks
 */
public interface Stack<T> {
    
    
    /**
    * Returns the number of elements in the stack.
    * @return number of elements in the stack
    */
  int size( );

   /**
    * Tests whether the stack is empty.
    * @return true if the stack is empty false otherwise
    */
   boolean isEmpty( );

   /**
    * Inserts an element at the top of the stack.
    * @param t the element added
    */
   void push(T t);

   /**
    * Returns, but does not remove, the element at the top of the stack.
    * @return top element in the stack (or null if empty)
    */
   T top( );

   /**
    * Removes and returns the top element from the stack.
    * @return element removed (or null if empty)
    */
   T pop( );
    
        
    
}
