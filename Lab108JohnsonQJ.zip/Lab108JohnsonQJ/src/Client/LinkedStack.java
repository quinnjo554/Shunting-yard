package Client;


/**
 *LinkedStack Class
 * Code Fragments 6.4
 * from
 * Data Structures & Algorithms, 6th edition
 * by Michael T.Goodrich, Roberto Tamassia &; Michael H. Goldwasser
 Wiley 2014
 Transcribed by
 * @author Quinn Johnson
 * @param <T>
 */
public class LinkedStack<T> implements Stack<T> {
     
 private SinglyLinkedList<T> list = new SinglyLinkedList<>( );    // an empty list
 public LinkedStack( ) {}            // new stack relies on the initially empty list
 
 /**
  * returns the stack size
  * @return int 
  */
  public int size( ) { 
      return list.size( ); 
  }
  /**
   * returns true if empty false otherwise
   * @return true if empty false otherwise 
   */
  public boolean isEmpty( ) {
      return list.isEmpty( ); 
  }
  
  
  /**
   * adds element to front of List
   * @param element added
   */
  public void push(T element) { 
      list.addFirst(element); 
  }
  /**
   * returns the first element
   * @return T first element 
   */
  public T top( ) { 
      return list.first( ); 
  }
  /**
   * removes the first element and returns its value
   * @return T element removed
   */
  public T pop( ) { 
      return list.removeFirst( ); 
  }
 }

