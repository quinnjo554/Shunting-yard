/**
 *Tree Interface
 * Code Fragments 8.2
 * from
 * Data Structures & Algorithms, 6th edition
 * by Michael T.Goodrich, Roberto Tamassia &; Michael H. Goldwasser Wiley 2014
 * transcribed by Quinn Johnson
 * @version April 2 2022
 * 
 */
package Client;


public abstract class Tree<E> implements AbstractTree<E> {
    public boolean isInternal(Position<E> p) { return numChildren(p) > 0; }
 public boolean isExternal(Position<E> p) { return numChildren(p) == 0; }
 public boolean isRoot(Position<E> p) { return p == root( ); }
 public boolean isEmpty( ) { return size( ) == 0; }
 }

