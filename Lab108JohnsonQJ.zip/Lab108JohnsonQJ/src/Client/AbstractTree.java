
package Client;
import java.util.Iterator;
/**
 *AbstractTree Class
 * Code Fragments 8.1
 * from
 * Data Structures & Algorithms, 6th edition
 * by Michael T.Goodrich, Roberto Tamassia &; Michael H. Goldwasser
 Wiley 2014
 * transcribed by Quinn Johnson
 * @version April 2 2022
 * 
 */
public interface AbstractTree<T> extends Iterable<T> {
    Position<T> root( );
    Position<T> parent(Position<T> p) throws IllegalArgumentException;
    Iterable<Position<T>> children(Position<T> p) throws IllegalArgumentException;
    
    
  int numChildren(Position<T> p) throws IllegalArgumentException;
  boolean isInternal(Position<T> p) throws IllegalArgumentException;
  boolean isExternal(Position<T> p) throws IllegalArgumentException;
  boolean isRoot(Position<T> p) throws IllegalArgumentException;
  int size( );
  boolean isEmpty( );
  Iterator<T> iterator( );
  Iterable<Position<T>> positions( );    
 
     
     
     
}
