
package Client;

/**
 *AbstractTree Class
 * Code Fragments 8.1
 * from
 * Data Structures & Algorithms, 6th edition
 * by Michael T.Goodrich, Roberto Tamassia &; Michael H. Goldwasser
 Wiley 2014
 * transcribed by Quinn Johnson
 * @version April 2 2022
 * 
 */
public interface BinaryTree<E> extends AbstractTree<E> {
     /** Returns the Position of p's left child (or null if no child exists). */
   Position<E> left(Position<E> p) throws IllegalArgumentException;
   /** Returns the Position of p's right child (or null if no child exists). */
   Position<E> right(Position<E> p) throws IllegalArgumentException;
   /** Returns the Position of p's sibling (or null if no sibling exists). */
  Position<E> sibling(Position<E> p) throws IllegalArgumentException;
}
