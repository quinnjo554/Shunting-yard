/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * makes use of the shunting yard algorithum then turns the expression into a
 * tree
 *
 * @author quinn
 */
public class Client {

    /**
     * takes a string by user and uses it as the path for a file
     * @return file with path given by user
     */
    public static File getFile() {

        String path = "";
        File absolute;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter file absolute path: ");

        //save the path
        path = scan.nextLine();
        //set the directory to a new file with the path
        absolute = new File(path);

        return absolute;
    }

    /**
     * identifies if the param is a number or not
     * @param string
     * @return true if string is a number false otherwise
     */
    public static boolean isNumber(String string) {

        try {
            //cast to a double
            double doubleValue = Double.parseDouble(string);
            //return true if cast was sucsessful
            return true;
        } catch (NumberFormatException e) {
            //false otherwise
            return false;
        }

    }

    /**
     * takes a postfix expression and converts to a binary tree
     * @param postfix
     * @return binary tree representing the equation
     */
    public static LinkedBinaryTree binaryTree(String postfix) {

        Scanner scan = new Scanner(postfix);
        LinkedStack<LinkedBinaryTree> stack = new LinkedStack();
        LinkedQueue<String> queue = new LinkedQueue();

        while (scan.hasNext()) {
            //add all elements to queue
            queue.enqueue(scan.next());
        }

        while (!queue.isEmpty()) {
            //tree that will added to the stack
            LinkedBinaryTree<String> tree = new LinkedBinaryTree();
            //if the first in the queue is a number
            if (isNumber(queue.first())) {
                //make the tree root the first in the queue
                tree.addRoot(queue.dequeue());
                //push to the stack
                stack.push(tree);

            } //if its an operator
            else {

                tree.addRoot(queue.dequeue());
                //init binarytrees used for left and right child
                LinkedBinaryTree<String> treeRight = new LinkedBinaryTree();
                LinkedBinaryTree<String> treeLeft = new LinkedBinaryTree();
                //set right and left as tree from stack
                treeRight = stack.pop();
                treeLeft = stack.pop();

                tree.attach(tree.root(), treeLeft, treeRight);
                //add tree to to stack
                stack.push(tree);

            }

        }
        //return the tree left on the stack
        if (stack.size() == 1) {
            return stack.pop();
        }
        //basse
        return null;

    }

    /**
     * add's the parentheses in an expression so they equal zero when they are balanced
     * @param stringLine
     * @return true if the equation is balanced false otherwise
     */
    public static boolean isBalanced(String stringLine) {
        char[] lineChar;
        //makes string line an array of chars
        lineChar = stringLine.toCharArray();
        //var checks balance
        int balance = 0;

        for (int i = 0; i < lineChar.length; i++) {
            switch (lineChar[i]) {
                case '(':
                    balance++;
                    break;
                case ')':
                    balance--;
                    break;
                case '[':
                    balance += 2;
                    break;
                case ']':
                    balance -= 2;
                    break;
                case '{':
                    balance += 3;
                    break;
                case '}':
                    balance -= 3;
                    break;
                default:
                    break;
            }

        }
        //return if balence equals zero
        return balance == 0;

    }

    /**
     *
     * @param string
     * @return true if string is an operator false otherwise
     */
    public static boolean isOperator(String string) {
        boolean isOperator = false;
        if (string.equals("*") || string.equals("+") || string.equals("-") || string.equals("/")) {
            //if its an operator
            isOperator = true;
        }
        return isOperator;
    }

    /**
     * gets the highest precedence operator
     *
     * @param s1 string representation of an operator to check for presedence
     * @return 2 if multiplacation or division
     */
    public static int getPresedence(String string) {
        
        if (string.equals("*") || string.equals("/")) {
            //if the string is * or /
            return 2;
        }
        if (string.equals("+") || string.equals("-")) {
            //if the string is a  +, or -
            return 1;
        }
        //if its not a valid operator
        return -1;
    }

    /**
     * runs logic for shunting yard
     * prints and evaluates my expression 
     * @param args
     * @throws Exception 
     */
    public static void main(String[] args) throws Exception {

        //Init of structures for shunting yard
        LinkedStack<String> stack = new LinkedStack();
        LinkedQueue<String> newLeft = new LinkedQueue();
        LinkedQueue<String> queueLeft = new LinkedQueue();

        //variable to be used for expetion
        int numOfOperators = 0;
        int numOfNumbers = 0;

        //File file = getFile();
        File file = getFile();

        try {
            Scanner parseFile = new Scanner(file);

            while (parseFile.hasNext()) {
                //getting the line
                String stringRead = parseFile.nextLine();
                //checks if the equation has balanced parentheses
                if (isBalanced(stringRead) == false) {
                    System.out.printf("Invalid Expression\n");
                    
                    continue;
                }

                //going through the line
                Scanner parseLine = new Scanner(stringRead);
                System.out.printf(stringRead + "\n");
                
                //while there is more to read
                while (parseLine.hasNext()) {

                    String letter = parseLine.next();

                    if (isNumber(letter)) { //is a digit
                        //add to the left queue
                        queueLeft.enqueue(letter);
                        numOfNumbers++;
                    } 
                    else if (letter.equals("(") || letter.equals("{") || letter.equals("[")) { //leftparen() method
                        //push to the stack
                        stack.push(letter);
                    } 
                    else if (letter.equals(")") || letter.equals("}") || letter.equals("]")) { //rightParen()
                        //going through untill we find a closing  
                        while (!stack.isEmpty() && (!stack.top().equals("(") && !stack.top().equals("{") && !stack.top().equals("["))) {
                            queueLeft.enqueue(stack.pop());
                        }

                        stack.pop();
                    } //if an operator is encountered + or -
                    else {
                        while (!stack.isEmpty() && getPresedence(letter) <= getPresedence(stack.top())) {
                            queueLeft.enqueue(stack.pop());

                        }
                        stack.push(letter);
                        numOfOperators++;
                    }

                }
                //after the line has been read and the stack isnt empty
                while (!stack.isEmpty()) {
                    if (stack.top().equals("(") || stack.top().equals("{") || stack.top().equals("[")) {
                        //file invalid
                        System.out.printf("Invalid Expression\n");
                        continue;
                    }

                    queueLeft.enqueue(stack.pop());

                }
                //check for balenced expression
                if (numOfNumbers - 1 != numOfOperators) {
                     
                    System.out.printf("Invalid Expression\n");
                    continue;
                } 
                
                
                
                

                String postfix = "";
                //loops through postfix and saves elements in 
                while (!queueLeft.isEmpty()) {
                    String dequeued = queueLeft.dequeue();
                    //newLeft now holds all elements
                    newLeft.enqueue(dequeued);
                    postfix += dequeued + " ";
                }
                //output postfix
                System.out.printf("Post-Fix : ");
                System.out.printf(postfix + "\n");

                //queueLeft = temp why does this slow everything down
                //evaluation
                //new queue to move the elements over to
                LinkedQueue<String> queueRight = new LinkedQueue();
                String answer = "";
                //moveing elements to the right queue for evaluation

                while (!newLeft.isEmpty()) {
                    queueRight.enqueue(newLeft.dequeue());
                }

                //loop through queueRight
                while (!queueRight.isEmpty()) {
                    //element is the 
                    String element = queueRight.dequeue();

                    //checks if the expression is only one number if so then the eval is itself
                    if (numOfNumbers == 1) {
                        answer = element;
                    }

                    //if element is a number 
                    if (isNumber(element)) {
                        //push to the stack
                        stack.push(element);
                    } //if its an operator
                    else if (isOperator(element) && !stack.isEmpty()) {
                        //get the va;ues from the stack to evaluate
                        double sckElement = Double.valueOf(stack.pop());
                        double sckElement2 = Double.valueOf(stack.pop());
                        //if its a plus add
                        if (element.equals("+")) {
                            answer = String.valueOf(sckElement2 + sckElement);
                        } //if its a - subtract
                        else if (element.equals("-")) {
                            answer = String.valueOf(sckElement2 - sckElement);
                        } //if its a * multiply
                        else if (element.equals("*")) {
                            answer = String.valueOf(sckElement2 * sckElement);
                        } //if its a / divide
                        else if (element.equals("/")) {
                            answer = String.valueOf(sckElement2 / sckElement);
                        }

                        //push answer
                        stack.push(answer);

                    }

                }
                //print the eval
                System.out.printf("Evaluation : " + answer + "\n");

                //get the postfixed tree
                LinkedBinaryTree tree;
                tree = binaryTree(postfix);
                //print the trees
                System.out.printf("  Euler Tour \n");
                System.out.printf("Pre-Order: ");
                tree.preorderSubtree(tree.root(), tree);
                System.out.printf("\nIn-Order: ");
                tree.inorderSubtree(tree.root(), tree);
                System.out.printf("\nPost-Order: ");
                tree.postorderSubtree(tree.root(), tree);
                System.out.printf("\nParenthiaized: ");
                tree.parenthiaized(tree, tree.root());
                System.out.printf("\n\n");
               
                //emptying the stack
                while (!stack.isEmpty()) {
                    stack.pop();
                }
                //reset variables
                numOfNumbers = 0;
                numOfOperators = 0;
            }

        } 
        //thrown if there is no file
        catch (FileNotFoundException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
