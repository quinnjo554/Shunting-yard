package LinkedBinaryTree;


/**
 * LinkedQueue Class
 * Code Fragments 6.11
 * from
 * Data Structures & Algorithms, 6th edition
 * by Michael T.Goodrich, Roberto Tamassia &; Michael H. Goldwasser
 Wiley 2014
 Transcribed by
/**
 * 
 * @author quinn
 * @param <T> 
 */
public class LinkedQueue<T> implements Queue<T> {
    private SinglyLinkedList<T> list = new SinglyLinkedList<>( );     // an empty list
  public LinkedQueue( ) { } // new queue relies on the initially empty list
  
  
  /**
   * 
   * @return size of the list
   */
    @Override
  public int size( ) { 
      return list.size( );
  }
  
  /**
   * determines if the list is empty
   * @return true if empty, false otherwise
   */
    @Override
  public boolean isEmpty( ) { 
      return list.isEmpty( );
  }
  
  /**
   * adds to end of queue
   * @param element to be added to the end
   */
    @Override
  public void enqueue(T element) { 
      list.addLast(element); 
  }
  /**
   * 
   * @return T the value of the first in the list
   */
    @Override
  public T first( ) {
      return list.first( );
  }
  /**
   * removes the first element in the list
   * @return T the value of the removed 
   */
    @Override
  public T dequeue( ) { 
      return list.removeFirst( );
  }
}
