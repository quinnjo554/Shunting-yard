/**
 *Linked Binary Tree Class
 * Code Fragments 8.8, 8.9, 8.11, 8.10
 * from
 * Data Structures & Algorithms, 6th edition
 * by Michael T.Goodrich, Roberto Tamassia &; Michael H. Goldwasser Wiley 2014
 * transcribed by Quinn Johnson
 * @version April 2 2022
 * 
 */
package LinkedBinaryTree;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/**
 *
 * 
 * 
 * @author quinn johnson
 * @version April 2 2022
 * 
 * Binary tree implementation with linked list
 */
public class LinkedBinaryTree<E> extends AbstractBinaryTree<E> {

    //---------------- nested ElementIterator class ----------------
    /* This class adapts the iteration produced by positions() to return elements. */
    private class ElementIterator implements Iterator<E> {

        Iterator<Position<E>> posIterator = new PositionIterator();

        public boolean hasNext() {
            return posIterator.hasNext();
        }

        public E next() {
            return posIterator.next().getElement();
        } // return element!

        public void remove() {
            posIterator.remove();
        }
    }

    /**
     * Returns an iterable representation of the list's positions.
     */
    public Iterable<Position<E>> positions() {
        return new PositionIterable();      // create a new instance of the inner class
    }

    //---------------- nested PositionIterable class ----------------
    private class PositionIterable implements Iterable<Position<E>> {

        public Iterator<Position<E>> iterator() {
            return new PositionIterator();
        }
    } //------------ end of nested PositionIterable class ------------

    @Override
    public Iterator<E> iterator() {
        return new ElementIterator();
    }

    //---------------- nested Node class ----------------
    protected static class Node<E> implements Position<E> {

        private E element;                 // an element stored at this node
        private Node<E> parent;            // a reference to the parent node (if any)
        private Node<E> left;              // a reference to the left child (if any)
        private Node<E> right;             // a reference to the right child (if any)

        /**
         * Constructs a node with the given element and neighbors.
         */
        public Node(E e, Node<E> above, Node<E> leftChild, Node<E> rightChild) {
            element = e;
            parent = above;
            left = leftChild;
            right = rightChild;
        }
        // accessor methods

        @Override
        public E getElement() {
            return element;
        }

        public Node<E> getParent() {
            return parent;
        }

        public Node<E> getLeft() {
            return left;
        }

        public Node<E> getRight() {
            return right;
        }
        // update methods

        public void setElement(E e) {
            element = e;
        }

        public void setParent(Node<E> parentNode) {
            parent = parentNode;
        }

        public void setLeft(Node<E> leftChild) {
            left = leftChild;
        }

        public void setRight(Node<E> rightChild) {
            right = rightChild;
        }
    } //----------- end of nested Node class -----------

    /**
     * Factory function to create a new node storing element e.
     */
    protected Node<E> createNode(E e, Node<E> parent,
            Node<E> left, Node<E> right) {
        return new Node<E>(e, parent, left, right);
    }

    // LinkedBinaryTree instance variables
    protected Node<E> root = null;          // root of the tree
    private int size = 0;                   // number of nodes in the tree

    // constructor
    public LinkedBinaryTree() {
    }

    //SECOND FROM BOOK
    // nonpublic utility
    /**
     * Validates the position and returns it as a node.
     */
    protected Node<E> validate(Position<E> p) throws IllegalArgumentException {
        if (!(p instanceof Node)) {
            throw new IllegalArgumentException("Not valid position type");
        }
        Node<E> node = (Node<E>) p;               // safe cast
        if (node.getParent() == node) // our convention for defunct node
        {
            throw new IllegalArgumentException("p is no longer in the tree");
        }
        return node;
    }

    // accessor methods (not already implemented in AbstractBinaryTree)
    /**
     * Returns the number of nodes in the tree.
     */
    public int size() {
        return size;
    }

    /**
     * Returns the root Position of the tree (or null if tree is empty).
     */
    public Position<E> root() {
        return root;
    }

    /**
     * Returns the Position of p's parent (or null if p is root).
     */
    public Position<E> parent(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        return node.getParent();
    }

    /**
     * Returns the Position of p's left child (or null if no child exists).
     */
    public Position<E> left(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        return node.getLeft();
    }

    /**
     * Returns the Position of p's right child (or null if no child exists).
     */
    public Position<E> right(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        return node.getRight();
    }

    // update methods supported by this class
    /**
     * Places element e at the root of an empty tree and returns its new
     * Position.
     */
    public Position<E> addRoot(E e) throws IllegalStateException {
        if (!isEmpty()) {
            throw new IllegalStateException("Tree is not empty");
        }
        root = createNode(e, null, null, null);
        size = 1;
        return root;
    }

    /**
     * Creates a new left child of Position p storing element e; returns its
     * Position.
     */
    public Position<E> addLeft(Position<E> p, E e)
            throws IllegalArgumentException {
        Node<E> parent = validate(p);
        if (parent.getLeft() != null) {
            throw new IllegalArgumentException("p already has a left child");
        }
        Node<E> child = createNode(e, parent, null, null);
        parent.setLeft(child);
        size++;
        return child;
    }

    /**
     * Creates a new right child of Position p storing element e; returns its
     * Position.
     */
    public Position<E> addRight(Position<E> p, E e)
            throws IllegalArgumentException {
        Node<E> parent = validate(p);
        if (parent.getRight() != null) {
            throw new IllegalArgumentException("p already has a right child");
        }
        Node<E> child = createNode(e, parent, null, null);
        parent.setRight(child);
        size++;
        return child;
    }

    /**
     * Replaces the element at Position p with e and returns the replaced
     * element.
     */
    public E set(Position<E> p, E e) throws IllegalArgumentException {
        Node<E> node = validate(p);
        E temp = node.getElement();
        node.setElement(e);
        return temp;
    }

    /**
     * Attaches trees t1 and t2 as left and right subtrees of external p.
     */
    public void attach(Position<E> p, LinkedBinaryTree<E> t1,
            LinkedBinaryTree<E> t2) throws IllegalArgumentException {
        Node<E> node = validate(p);
        if (isInternal(p)) {
            throw new IllegalArgumentException("p must be a leaf");
        }
        size += t1.size() + t2.size();
        if (!t1.isEmpty()) {                     // attach t1 as left subtree of node
            t1.root.setParent(node);
            node.setLeft(t1.root);
            t1.root = null;
            t1.size = 0;
        }
        if (!t2.isEmpty()) {                    // attach t2 as right subtree of node
            t2.root.setParent(node);
            node.setRight(t2.root);
            t2.root = null;
            t2.size = 0;
        }
    }

    /**
     * Removes the node at Position p and replaces it with its child, if any.
     */
    public E remove(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        if (numChildren(p) == 2) {
            throw new IllegalArgumentException("p has two children");
        }
        Node<E> child = (node.getLeft() != null ? node.getLeft() : node.getRight());
        if (child != null) {
            child.setParent(node.getParent());  // child's grandparent becomes its parent
        }
        if (node == root) {
            root = child;                        // child becomes root
        } else {
            Node<E> parent = node.getParent();
            if (node == parent.getLeft()) {
                parent.setLeft(child);
            } else {
                parent.setRight(child);
            }
        }
        size--;
        E temp = node.getElement();
        node.setElement(null);           // help garbage collection
        node.setLeft(null);
        node.setRight(null);
        node.setParent(node);            // our convention for defunct node
        return temp;
    }

    //FIX LOGIC ERROR
    //---------------- nested PositionIterator class ----------------
    private class PositionIterator implements Iterator<Position<E>> {

        private Position<E> cursor = root();  // position of the next element to report
        private Position<E> recent = null;      // position of last reported element

        /**
         * Tests whether the iterator has a next object.
         */
        public boolean hasNext() {
            return (cursor != null);
        }

        /**
         * Returns the next position in the iterator.
         */
        public Position<E> next() throws NoSuchElementException {
            if (cursor == null) {
                throw new NoSuchElementException("nothing left");
            }
            recent = cursor;           // element at this position might later be removed
            cursor = left(cursor);
            return recent;
        }

        /**
         * Removes the element returned by most recent call to next.
         */
        public void remove() throws IllegalStateException {
            if (recent == null) {
                throw new IllegalStateException("nothing to remove");
            }
            LinkedBinaryTree.this.remove(recent);          // remove from outer list
            recent = null;                 // do not allow remove again until next is called
        }
    } //------------ end of nested PositionIterator class ------------

    /**
     *
     * @param p
     * @param snapshot
     */
    public void inorderSubtree(Position<E> p, LinkedBinaryTree<Position<E>> snapshot) {

        if (left(p) != null) {
            //if tree isnt null recursive call with left and snap untill null
            inorderSubtree(left(p), snapshot);

        }
        //print element when done with left
        System.out.print(p.getElement());

        if (right(p) != null) {
            //do the same with the right
            inorderSubtree(right(p), snapshot);

        }

    }
    
    /**
     * returns the height of the tree
     * @param p
     * @return height of tree
     */
    public int height(Position<E> p) {
        int h = 0;  // base case if p is external
        for (Position<E> c : children(p)) {
            h = Math.max(h, 1 + height(c));
        }
        return h;
    }

    /**
     * prints tree with given position in pre order
     * @param p
     * @param snapshot
     */
    public void preorderSubtree(Position<E> p, LinkedBinaryTree<Position<E>> snapshot) {

        System.out.print(p.getElement());
        for (Position<E> c : children(p)) {
            preorderSubtree(c, snapshot);
        }

    }

    /**
     *prints tree with given position in post order
     * @param p
     * @param snapshot
     */
    public void postorderSubtree(Position<E> p, LinkedBinaryTree<Position<E>> snapshot) {
        for (Position<E> c : children(p)) {
            postorderSubtree(c, snapshot);
        }

        System.out.print(p.getElement());      // for postorder, we print position p after exploring subtrees
    }

    /**
     * prints tree in breadthfirst order
     * @return iterable position
     */
    public Iterable<Position<E>> breadthfirst() {
     
        List<Position<E>> snapshot = new ArrayList<>();
        
        if (!isEmpty()) { 
            Queue<Position<E>> fringe = new LinkedQueue<>();
            fringe.enqueue(root());             // start with the root
            while (!fringe.isEmpty()) {
                Position<E> p = fringe.dequeue(); // remove from front of the queue
                System.out.printf("%s",p.getElement());                   // report this position
                for (Position<E> c : children(p)) {
                    fringe.enqueue(c);               // add children to back of queue
                }
            }
        }
        return snapshot;
    }

    
    /**
     * takes a tree and adds parenthises in subtrees
     * @param main linked Binary Tree
     * @param p position
     */
    public void parenthiaized(LinkedBinaryTree<Position<E>> main, Position<E> p) {
        
        if (left(p) != null) { //checks if left child is null
            
            //if not check if it has children
            if (isInternal(p)) {
                //if it has children print open (
                System.out.printf("(");
            }
            //recursive call with main and left untill null
            parenthiaized(main, left(p));
        }
        //print element when left is null
        System.out.print(p.getElement());
        
       
        if (right(p) != null) { //check if right child is null
            
            parenthiaized(main, right(p));//recursive call with main and right untill null
            if (isInternal(p)) {
                System.out.printf(")"); // print close )
            }
        }

    }
    
    //-------END OF LINKEDBINARYTREE-------

}
